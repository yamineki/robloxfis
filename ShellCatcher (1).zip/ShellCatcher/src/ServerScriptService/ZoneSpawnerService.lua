--[[
	ZoneSpawnerService.lua  (ServerScriptService)
	Спавнит силуэты добычи (для Harpoon Net) и ресурсные блоки (для Crusher Drill)
	в каждой открытой зоне. Силуэты не раскрывают вид/редкость заранее — это решается
	в момент поимки в HarpoonToolService (RNG-момент).
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local TweenService = game:GetService("TweenService")
local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))

local ZoneSpawnerService = {}

local SILHOUETTE_BASE_HEALTH = 20
local RESOURCE_BLOCK_BASE_HEALTH = 30
local MAX_SILHOUETTES_PER_ZONE = 18
local MAX_RESOURCE_BLOCKS_PER_ZONE = 10
local SPAWN_CHECK_INTERVAL = 3

local resourceIdsByHazard = {
	[0] = { "scrap", "shellfragment" },
	[1] = { "scrap", "shellfragment", "darkpearl" },
	[2] = { "obsidianite", "magmacrystal" },
}

local function getZoneConfig(zoneId)
	for _, zone in ipairs(GameConfig.Zones) do
		if zone.Id == zoneId then return zone end
	end
	return nil
end

local function spawnSilhouette(zoneFolder, zoneConfig)
	local spawnPoints = zoneFolder:FindFirstChild("CreatureSpawnPoints")
	if not spawnPoints or #spawnPoints:GetChildren() == 0 then return end

	local point = spawnPoints:GetChildren()[math.random(1, #spawnPoints:GetChildren())]

	local silhouette = Instance.new("Part")
	silhouette.Name = "Silhouette"
	silhouette.Shape = Enum.PartType.Block
	silhouette.Size = Vector3.new(2.5, 2.5, 1)
	silhouette.Color = Color3.new(0, 0, 0) -- чёрный силуэт, вид не раскрыт
	silhouette.Material = Enum.Material.SmoothPlastic
	silhouette.Anchored = true   -- двигаем твином, поэтому якорим: иначе часть тонула бы от гравитации
	silhouette.CanCollide = false
	silhouette.CFrame = point.CFrame

	silhouette:SetAttribute("Health", SILHOUETTE_BASE_HEALTH)
	silhouette:SetAttribute("BaseValue", 5 * zoneConfig.CatchValueMultiplier)
	silhouette:SetAttribute("CreatureId", "silhouette_" .. zoneConfig.Id)

	silhouette.Parent = zoneFolder:FindFirstChild("Creatures") or zoneFolder

	-- Простое блуждающее движение, чтобы силуэт не стоял колом
	task.spawn(function()
		while silhouette.Parent do
			local offset = Vector3.new(
				math.random(-15, 15) / 10,
				math.random(-5, 5) / 10,
				math.random(-15, 15) / 10
			)
			local goal = silhouette.Position + offset
			local tween = TweenService:Create(
				silhouette,
				TweenInfo.new(math.random(2, 4)),
				{ Position = goal }
			)
			tween:Play()
			tween.Completed:Wait()
			-- Если силуэт уничтожен во время твина (пойман игроком), выходим из цикла
			if not silhouette.Parent then break end
		end
	end)
end

local function spawnResourceBlock(zoneFolder, zoneConfig)
	local spawnPoints = zoneFolder:FindFirstChild("ResourceSpawnPoints")
	if not spawnPoints or #spawnPoints:GetChildren() == 0 then return end

	local point = spawnPoints:GetChildren()[math.random(1, #spawnPoints:GetChildren())]
	local possibleResources = resourceIdsByHazard[zoneConfig.HazardLevel] or resourceIdsByHazard[0]
	local resourceId = possibleResources[math.random(1, #possibleResources)]

	local block = Instance.new("Part")
	block.Name = "ResourceBlock"
	block.Shape = Enum.PartType.Block
	block.Size = Vector3.new(3, 3, 3)
	block.Anchored = true
	block.CanCollide = true
	block.CFrame = point.CFrame
	block.Material = Enum.Material.Rock

	block:SetAttribute("Health", RESOURCE_BLOCK_BASE_HEALTH)
	block:SetAttribute("ResourceId", resourceId)
	block:SetAttribute("Amount", math.random(1, 3))

	block.Parent = zoneFolder:FindFirstChild("Resources") or zoneFolder
end

function ZoneSpawnerService.StartSpawningForZone(zoneId)
	local zoneConfig = getZoneConfig(zoneId)
	if not zoneConfig then
		warn("[ZoneSpawnerService] Неизвестная зона:", zoneId)
		return
	end

	local zoneFolder = workspace:FindFirstChild("Zones") and workspace.Zones:FindFirstChild(zoneId)
	if not zoneFolder then
		warn("[ZoneSpawnerService] Папка зоны не найдена в workspace:", zoneId)
		return
	end

	task.spawn(function()
		while true do
			task.wait(SPAWN_CHECK_INTERVAL)

			local creaturesFolder = zoneFolder:FindFirstChild("Creatures")
			local currentSilhouettes = creaturesFolder and #creaturesFolder:GetChildren() or 0
			if currentSilhouettes < MAX_SILHOUETTES_PER_ZONE then
				spawnSilhouette(zoneFolder, zoneConfig)
			end

			local resourcesFolder = zoneFolder:FindFirstChild("Resources")
			local currentResources = resourcesFolder and #resourcesFolder:GetChildren() or 0
			if currentResources < MAX_RESOURCE_BLOCKS_PER_ZONE then
				spawnResourceBlock(zoneFolder, zoneConfig)
			end
		end
	end)
end

function ZoneSpawnerService.StartAllZones()
	for _, zone in ipairs(GameConfig.Zones) do
		ZoneSpawnerService.StartSpawningForZone(zone.Id)
	end
end

return ZoneSpawnerService
