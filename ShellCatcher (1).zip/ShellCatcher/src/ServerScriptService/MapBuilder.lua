--[[
	MapBuilder.lua  (ServerScriptService, ModuleScript)
	Строит ВСЮ геометрию игры кодом из простых Part — остров, 4 зоны лова,
	здания, NPC. Это заглушка-скелет: формы, размеры и цвета условные,
	но ИМЕНА и ИЕРАРХИЯ совпадают с тем, что ожидают остальные сервисы
	(ZoneService, ZoneSpawnerService, AfkSorterService и т.д.), поэтому
	игра полностью играбельна уже на этой геометрии.

	Вызывается ОДИН раз при старте сервера из Main.server.lua, ДО
	ZoneSpawnerService.StartAllZones().

	КАК ЗАМЕНИТЬ ЗАГЛУШКИ НА СВОЙ АРТ — см. подробный гайд в конце файла
	и в docs/README.md (раздел "Замена заглушек карты").
]]

local ReplicatedStorage = game:GetService("ReplicatedStorage")
local GameConfig = require(ReplicatedStorage:WaitForChild("GameConfig"))

local MapBuilder = {}

-- ============================================================
-- Хелперы создания Part-заглушек
-- ============================================================

local function makePart(name, parent, size, position, color, material, shape)
	local part = Instance.new("Part")
	part.Name = name
	part.Size = size
	part.Position = position
	part.Color = color or Color3.fromRGB(120, 120, 130)
	part.Material = material or Enum.Material.SmoothPlastic
	part.Shape = shape or Enum.PartType.Block
	part.Anchored = true
	part.Parent = parent
	return part
end

-- Невидимая точка спавна — обычная Part без коллизии и без видимости,
-- остальные сервисы используют только её CFrame
local function makeSpawnPoint(name, parent, position)
	local point = Instance.new("Part")
	point.Name = name
	point.Size = Vector3.new(2, 1, 2)
	point.Position = position
	point.Anchored = true
	point.CanCollide = false
	point.Transparency = 1
	point.Parent = parent
	return point
end

-- Текстовая подпись над заглушкой здания/NPC (BillboardGui), чтобы было понятно
-- что где, пока нет реальных моделей
local function addNameTag(part, text, color)
	local billboard = Instance.new("BillboardGui")
	billboard.Name = "NameTag"
	billboard.Size = UDim2.fromOffset(160, 40)
	billboard.StudsOffset = Vector3.new(0, part.Size.Y / 2 + 1.5, 0)
	billboard.AlwaysOnTop = true
	billboard.Parent = part

	local label = Instance.new("TextLabel")
	label.Size = UDim2.fromScale(1, 1)
	label.BackgroundTransparency = 0.4
	label.BackgroundColor3 = Color3.new(0, 0, 0)
	label.Text = text
	label.TextColor3 = color or Color3.new(1, 1, 1)
	label.Font = Enum.Font.GothamBold
	label.TextScaled = true
	label.Parent = billboard

	return billboard
end

-- Простой ProximityPrompt-каркас на здании — название действия настраивается вызывающим кодом
local function addProximityPrompt(part, actionText, objectText, holdDuration)
	local prompt = Instance.new("ProximityPrompt")
	prompt.ActionText = actionText
	prompt.ObjectText = objectText
	prompt.HoldDuration = holdDuration or 0
	prompt.MaxActivationDistance = 10
	prompt.RequiresLineOfSight = false
	prompt.Parent = part
	return prompt
end

-- ============================================================
-- 1. ОСТРОВ-ХАБ (общий для всех 6 игроков)
-- ============================================================

function MapBuilder.BuildIsland()
	local island = workspace:FindFirstChild("Island")
	if island then island:Destroy() end

	-- IslandSpawnPoints лежит отдельно в workspace (не внутри Island), поэтому
	-- чистим его отдельно, иначе при перезапуске скрипта появится дубль-папка.
	local oldSpawns = workspace:FindFirstChild("IslandSpawnPoints")
	if oldSpawns then oldSpawns:Destroy() end

	island = Instance.new("Folder")
	island.Name = "Island"
	island.Parent = workspace

	-- Основа острова — большая плоская плита песочного цвета
	local groundPart = makePart(
		"IslandGround", island,
		Vector3.new(120, 4, 120), Vector3.new(0, 0, 0),
		Color3.fromRGB(210, 190, 140), Enum.Material.Sand
	)

	-- Настоящий SpawnLocation, чтобы Roblox корректно спавнил игроков на острове
	-- при первом заходе (иначе персонаж падает из случайной точки над миром).
	-- onCharacterAdded потом всё равно телепортирует на IslandSpawnPoints, но это
	-- убирает полусекундное падение при заходе.
	local spawnLocation = Instance.new("SpawnLocation")
	spawnLocation.Name = "IslandSpawnLocation"
	spawnLocation.Size = Vector3.new(12, 1, 12)
	spawnLocation.Position = Vector3.new(0, 3, 0)
	spawnLocation.Anchored = true
	spawnLocation.Neutral = true
	spawnLocation.Duration = 0 -- без форс-филда
	spawnLocation.Color = Color3.fromRGB(230, 210, 160)
	spawnLocation.Parent = island

	-- Точки спавна персонажей на острове (используются ZoneService.ReturnToIsland)
	local islandSpawns = Instance.new("Folder")
	islandSpawns.Name = "IslandSpawnPoints"
	islandSpawns.Parent = workspace -- ZoneService ищет именно workspace.IslandSpawnPoints

	for i = 1, 6 do
		local angle = (i / 6) * math.pi * 2
		local x = math.cos(angle) * 15
		local z = math.sin(angle) * 15
		makeSpawnPoint("Spawn_" .. i, islandSpawns, Vector3.new(x, 4, z))
	end

	return island
end

-- ============================================================
-- 2. ЗДАНИЯ ОСТРОВА (заглушки-кубы, разного цвета по типу здания)
-- ============================================================

local buildingColors = {
	shop_basic     = Color3.fromRGB(90, 200, 120),  -- зелёный — торговая лавка
	storage_room   = Color3.fromRGB(160, 140, 100), -- коричневый — склад
	afk_dock       = Color3.fromRGB(80, 200, 255),  -- голубой — AFK-машина
	skin_workshop  = Color3.fromRGB(230, 90, 200),  -- розовый — мастерская скинов
	rebirth_altar  = Color3.fromRGB(250, 200, 70),  -- золотой — алтарь ребирта
}

function MapBuilder.BuildIslandBuildings()
	local island = workspace:FindFirstChild("Island")
	if not island then return end

	local buildingsFolder = Instance.new("Folder")
	buildingsFolder.Name = "Buildings"
	buildingsFolder.Parent = island

	-- Здания расставлены по кругу вокруг центра острова, на равном расстоянии
	local buildingCount = #GameConfig.IslandBuildings
	for index, buildingConfig in ipairs(GameConfig.IslandBuildings) do
		local angle = (index / buildingCount) * math.pi * 2
		local x = math.cos(angle) * 35
		local z = math.sin(angle) * 35

		local buildingPart = makePart(
			buildingConfig.Id, buildingsFolder,
			Vector3.new(10, 12, 10), Vector3.new(x, 6, z),
			buildingColors[buildingConfig.Id] or Color3.fromRGB(150, 150, 150)
		)

		addNameTag(buildingPart, buildingConfig.Name, buildingColors[buildingConfig.Id])

		-- Каждое здание получает ProximityPrompt — конкретная логика открытия окна
		-- привязывается в Main.server.lua (см. ниже), тут только сам прompt-каркас.
		local prompt = addProximityPrompt(buildingPart, "Open", buildingConfig.Name)
		prompt.Name = "BuildingPrompt_" .. buildingConfig.Id

		-- SoundId-заглушка на ambient-звук здания (можно вставить зацикленный фоновый звук,
		-- например жужжание станка для afk_dock). Пустой SoundId — звука не будет, пока
		-- не вставишь свой ID.
		local ambientSound = Instance.new("Sound")
		ambientSound.Name = "AmbientSound"
		ambientSound.SoundId = "" -- TODO: rbxassetid://ЗАМЕНИ_НА_СВОЙ_ЗВУК
		ambientSound.Looped = true
		ambientSound.Volume = 0.3
		ambientSound.Parent = buildingPart
	end
end

-- ============================================================
-- 3. NPC ОСТРОВА (заглушки-капсулы, неподвижные, с подписью имени)
-- ============================================================

local npcNames = {
	"Old Sailor Finn",
	"Net Mender Tilly",
	"Dock Boy Wren",
	"Lighthouse Keeper Ova",
	"Trader Bramble",
	"Curious Hermit Crab",
	"Sleepy Turtle Elder",
}

function MapBuilder.BuildIslandNPCs()
	local island = workspace:FindFirstChild("Island")
	if not island then return end

	local npcFolder = Instance.new("Folder")
	npcFolder.Name = "NPCs"
	npcFolder.Parent = island

	for index, npcName in ipairs(npcNames) do
		local angle = (index / #npcNames) * math.pi * 2
		local x = math.cos(angle) * 22
		local z = math.sin(angle) * 22

		-- Капсула вместо реальной модели персонажа — позже заменяется на Rig/Model
		local npcPart = makePart(
			"NPC_" .. index, npcFolder,
			Vector3.new(3, 6, 3), Vector3.new(x, 3, z),
			Color3.fromRGB(255, 220, 180), Enum.Material.SmoothPlastic, Enum.PartType.Cylinder
		)
		npcPart.Orientation = Vector3.new(0, 0, 90) -- цилиндр "стоит" вертикально

		addNameTag(npcPart, npcName, Color3.fromRGB(255, 230, 150))

		local prompt = addProximityPrompt(npcPart, "Talk", npcName)
		prompt.Name = "NPCPrompt_" .. index

		-- Звук "голоса" NPC при взаимодействии — заглушка
		local voiceSound = Instance.new("Sound")
		voiceSound.Name = "VoiceSound"
		voiceSound.SoundId = "" -- TODO: rbxassetid://ЗАМЕНИ_НА_СВОЙ_ЗВУК (бубнящий голос/чат-звук)
		voiceSound.Volume = 0.5
		voiceSound.Parent = npcPart
	end
end

-- ============================================================
-- 4. ЗОНЫ ЛОВА (4 шт., каждая — отдельная площадка в стороне от острова)
-- ============================================================

local zoneColors = {
	reef    = Color3.fromRGB(255, 200, 150),
	kelp    = Color3.fromRGB(80, 180, 100),
	trench  = Color3.fromRGB(60, 70, 110),
	vent    = Color3.fromRGB(200, 70, 50),
}

-- Зоны расставлены по прямой линии друг за другом, с увеличивающимся отступом —
-- условное "погружение глубже" по дизайну. Координата Y тоже понижается, чтобы
-- буквально передать рост глубины.
local zoneWorldOffsets = {
	reef   = Vector3.new(250, 0, 0),
	kelp   = Vector3.new(450, -30, 0),
	trench = Vector3.new(650, -70, 0),
	vent   = Vector3.new(850, -120, 0),
}

function MapBuilder.BuildZone(zoneConfig)
	local zonesRoot = workspace:FindFirstChild("Zones")
	if not zonesRoot then
		zonesRoot = Instance.new("Folder")
		zonesRoot.Name = "Zones"
		zonesRoot.Parent = workspace
	end

	local existing = zonesRoot:FindFirstChild(zoneConfig.Id)
	if existing then existing:Destroy() end

	local zoneFolder = Instance.new("Folder")
	zoneFolder.Name = zoneConfig.Id
	zoneFolder.Parent = zonesRoot

	local worldOffset = zoneWorldOffsets[zoneConfig.Id] or Vector3.new(0, 0, 0)

	-- Дно зоны — большая плоская плита под водой, цвет по биому
	makePart(
		"ZoneFloor", zoneFolder,
		Vector3.new(150, 4, 150), worldOffset - Vector3.new(0, 20, 0),
		zoneColors[zoneConfig.Id] or Color3.fromRGB(100, 100, 140),
		Enum.Material.Slate
	)

	-- Невидимый блок-маркер "вход в зону" с подписью названия и стоимости разблокировки —
	-- реальный вход/выход обрабатывается через UI и ZoneService.EnterZone, это просто
	-- визуальный ориентир на острове/между зонами.
	local entranceMarker = makePart(
		"ZoneEntranceMarker", zoneFolder,
		Vector3.new(6, 10, 6), worldOffset + Vector3.new(0, -10, 0),
		zoneColors[zoneConfig.Id] or Color3.fromRGB(100, 100, 140)
	)
	addNameTag(
		entranceMarker,
		string.format("%s\n(%d Shells)", zoneConfig.Name, zoneConfig.UnlockCost),
		zoneColors[zoneConfig.Id]
	)

	-- Точки спавна игрока при входе в зону (ZoneService.EnterZone ищет SpawnPoints)
	local spawnPoints = Instance.new("Folder")
	spawnPoints.Name = "SpawnPoints"
	spawnPoints.Parent = zoneFolder
	for i = 1, 6 do
		local angle = (i / 6) * math.pi * 2
		local x = math.cos(angle) * 10
		local z = math.sin(angle) * 10
		makeSpawnPoint("Spawn_" .. i, spawnPoints, worldOffset + Vector3.new(x, -15, z))
	end

	-- Точки спавна силуэтов добычи (ZoneSpawnerService ищет CreatureSpawnPoints)
	local creatureSpawnPoints = Instance.new("Folder")
	creatureSpawnPoints.Name = "CreatureSpawnPoints"
	creatureSpawnPoints.Parent = zoneFolder
	for i = 1, 14 do
		local x = math.random(-60, 60)
		local z = math.random(-60, 60)
		local y = math.random(-25, -5)
		makeSpawnPoint("CreatureSpawn_" .. i, creatureSpawnPoints, worldOffset + Vector3.new(x, y, z))
	end

	-- Точки спавна ресурсных блоков (ZoneSpawnerService ищет ResourceSpawnPoints)
	local resourceSpawnPoints = Instance.new("Folder")
	resourceSpawnPoints.Name = "ResourceSpawnPoints"
	resourceSpawnPoints.Parent = zoneFolder
	for i = 1, 10 do
		local x = math.random(-60, 60)
		local z = math.random(-60, 60)
		makeSpawnPoint("ResourceSpawn_" .. i, resourceSpawnPoints, worldOffset + Vector3.new(x, -19, z))
	end

	-- Пустые папки, куда ZoneSpawnerService будет класть спавненые силуэты/блоки
	local creaturesFolder = Instance.new("Folder")
	creaturesFolder.Name = "Creatures"
	creaturesFolder.Parent = zoneFolder

	local resourcesFolder = Instance.new("Folder")
	resourcesFolder.Name = "Resources"
	resourcesFolder.Parent = zoneFolder

	-- Зональный ambient-звук (например бурление воды/специфика биома) — заглушка
	local zoneAmbient = Instance.new("Sound")
	zoneAmbient.Name = "ZoneAmbientSound"
	zoneAmbient.SoundId = "" -- TODO: rbxassetid://ЗАМЕНИ_НА_СВОЙ_ЗВУК (амбиент зоны, looped)
	zoneAmbient.Looped = true
	zoneAmbient.Volume = 0.25
	zoneAmbient.Parent = entranceMarker

	return zoneFolder
end

function MapBuilder.BuildAllZones()
	for _, zoneConfig in ipairs(GameConfig.Zones) do
		MapBuilder.BuildZone(zoneConfig)
	end
end

-- ============================================================
-- Точка входа: строит абсолютно всё за один вызов
-- ============================================================

function MapBuilder.BuildEverything()
	MapBuilder.BuildIsland()
	MapBuilder.BuildIslandBuildings()
	MapBuilder.BuildIslandNPCs()
	MapBuilder.BuildAllZones()
	print("[MapBuilder] Карта-заглушка построена: остров, зданий — "
		.. #GameConfig.IslandBuildings .. ", зон — " .. #GameConfig.Zones)
end

return MapBuilder

--[[
	============================================================
	КАК ЗАМЕНИТЬ ЗАГЛУШКИ НА СВОЙ АРТ (краткая версия — полная в docs/README.md)
	============================================================

	1. ОСТРОВ (IslandGround):
	   Удали или спрячь Part "IslandGround", создай/импортируй свою модель острова
	   в то же место (around Vector3.new(0,0,0)). Главное — оставить Folder
	   "IslandSpawnPoints" в workspace с точками спавна персонажа.

	2. ЗДАНИЯ (workspace.Island.Buildings.<building_id>):
	   Каждое здание — один Part с ProximityPrompt-ребёнком "BuildingPrompt_<id>".
	   Замени сам Part на свою модель (Model), но переименуй Model точно так же
	   (например "shop_basic"), и перенеси внутрь Model дочерний ProximityPrompt
	   с тем же именем — остальной код ищет prompt по имени, не по типу Part/Model.

	3. NPC (workspace.Island.NPCs.NPC_<n>):
	   Замени капсулу на Rig/Model персонажа. Сохрани ProximityPrompt
	   "NPCPrompt_<n>" внутри модели.

	4. ЗОНЫ (workspace.Zones.<zone_id>):
	   - ZoneFloor — замени на свою геометрию дна/рельефа зоны.
	   - SpawnPoints / CreatureSpawnPoints / ResourceSpawnPoints — НЕ переименовывай
	     эти Folder, остальной код ищет их по точному имени. Можно свободно менять
	     количество точек внутри и их позиции — просто перетаскивай Part в Studio.
	   - Creatures / Resources — оставь пустыми, туда сервер кладёт спавненые объекты
	     во время игры (не трогай руками).

	5. СИЛУЭТЫ ДОБЫЧИ И РЕСУРСНЫЕ БЛОКИ:
	   Сейчас они генерируются кодом в ZoneSpawnerService.lua как чёрные кубы/камни
	   (см. функции spawnSilhouette/spawnResourceBlock). Чтобы заменить на свою модель:
	   замени там Instance.new("Part") на клонирование своего шаблона из
	   ReplicatedStorage (например ReplicatedStorage.Models.SilhouetteTemplate:Clone()),
	   и не забудь после клонирования всё равно проставлять Attribute Health/BaseValue/
	   CreatureId / ResourceId/Amount — на них зависит вся боевая логика.
]]
