--[[
	ToolController.client.lua  (StarterPlayerScripts)
	Переключение между двумя инструментами (1 = Harpoon Net, 2 = Crusher Drill)
	и обработка клика/тапа: рейкаст в точку под курсором, отправка цели на сервер.

	Сервер всё равно перепроверяет дистанцию и валидность цели (см. HarpoonToolService
	и CrusherDrillService) — клиент тут только для отзывчивости управления.
]]

local Players = game:GetService("Players")
local ReplicatedStorage = game:GetService("ReplicatedStorage")
local UserInputService = game:GetService("UserInputService")

local player = Players.LocalPlayer
local mouse = player:GetMouse()
local camera = workspace.CurrentCamera

local FireHarpoonRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("FireHarpoon")
local FireDrillRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("FireDrill")
local CatchResultRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("CatchResult")
local DrillOverheatRemote = ReplicatedStorage:WaitForChild("Remotes"):WaitForChild("DrillOverheat")

local equippedTool = "HarpoonNet" -- "HarpoonNet" | "CrusherDrill"
local drillOverheated = false

local function raycastFromMouse()
	local unitRay = camera:ViewportPointToRay(mouse.X, mouse.Y)

	local raycastParams = RaycastParams.new()
	raycastParams.FilterType = Enum.RaycastFilterType.Exclude
	raycastParams.FilterDescendantsInstances = { player.Character }

	local result = workspace:Raycast(unitRay.Origin, unitRay.Direction * 200, raycastParams)
	return result
end

local function attemptFire()
	local result = raycastFromMouse()
	if not result then return end

	local hitInstance = result.Instance

	if equippedTool == "HarpoonNet" then
		if hitInstance.Name == "Silhouette" then
			FireHarpoonRemote:FireServer(hitInstance)
		end
	elseif equippedTool == "CrusherDrill" then
		if not drillOverheated and hitInstance.Name == "ResourceBlock" then
			FireDrillRemote:FireServer(hitInstance)
		end
	end
end

-- Удержание кнопки/пальца = автоповтор по файрейту инструмента (упрощённая версия,
-- реальный файрейт всё равно ограничивается на сервере).
local isHolding = false

UserInputService.InputBegan:Connect(function(input, gameProcessed)
	if gameProcessed then return end

	if input.KeyCode == Enum.KeyCode.One then
		equippedTool = "HarpoonNet"
	elseif input.KeyCode == Enum.KeyCode.Two then
		equippedTool = "CrusherDrill"
	elseif input.UserInputType == Enum.UserInputType.MouseButton1
		or input.UserInputType == Enum.UserInputType.Touch then
		-- Один выстрел сразу по нажатию, дальше цикл удержания продолжит, пока зажато.
		isHolding = true
		attemptFire()
	end
end)

UserInputService.InputEnded:Connect(function(input)
	if input.UserInputType == Enum.UserInputType.MouseButton1
		or input.UserInputType == Enum.UserInputType.Touch then
		isHolding = false
	end
end)

task.spawn(function()
	while true do
		task.wait(0.15)
		if isHolding then
			attemptFire()
		end
	end
end)

CatchResultRemote.OnClientEvent:Connect(function(resultData)
	if resultData.Success then
		print(("Поймано: %s (%s)"):format(resultData.CreatureId, resultData.RarityId))
		-- Сюда вешается анимация раскрытия силуэта — вспышка цветом редкости и т.п.
	else
		print("Не удалось поймать:", resultData.Reason)
	end
end)

DrillOverheatRemote.OnClientEvent:Connect(function(isOverheated)
	drillOverheated = isOverheated
	-- Сюда вешается визуальный индикатор перегрева инструмента в UI.
end)
