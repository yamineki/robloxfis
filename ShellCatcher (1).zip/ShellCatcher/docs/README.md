# Shell Catcher — сборка проекта в Roblox Studio

## 0. Сборка через Rojo (рекомендуемый способ)

Проект настроен под Rojo. Корень содержит `default.project.json`, который описывает
всё дерево, и папку `src/` с исходниками.

**Запуск:**
1. Установи Rojo (через Aftman/Rokit или `cargo install rojo`, либо плагин Rojo в Studio).
2. В терминале в корне проекта: `rojo serve`
3. В Studio открой плагин Rojo → Connect.
4. Дерево соберётся автоматически.

Альтернатива без live-связи: `rojo build -o ShellCatcher.rbxlx` и открой полученный файл в Studio.

### Почему пропали ошибки "Infinite yield on WaitForChild(Remotes)"

Раньше папка `ReplicatedStorage.Remotes` создавалась скриптом во время выполнения.
Под Rojo обычный `.lua`-файл становится **ModuleScript** (не запускается сам), поэтому
скрипт-генератор `RemotesSetup` никогда не выполнялся → папки `Remotes` не было →
все сервисы зависали на `WaitForChild("Remotes")`.

**Решение:** папка `Remotes` со всеми 24 RemoteEvent теперь объявлена **статически**
прямо в `default.project.json`. Она существует в дереве до запуска любого скрипта,
поэтому `WaitForChild` резолвится мгновенно. То же сделано для `OpenShopBindable`.
Скрипт `RemotesSetup` удалён за ненадобностью.

### Как тип файла определяется в Rojo

| Имя файла | Что становится в Studio |
|---|---|
| `Name.lua` | ModuleScript (не запускается сам, только через `require`) |
| `Name.server.lua` | Script (серверный, запускается автоматически) |
| `Name.client.lua` | LocalScript (клиентский, запускается автоматически) |

Поэтому `Main.server.lua` — единственная точка входа сервера, а `MasterUI.client.lua`
и `ToolController.client.lua` — клиентские. Все остальные `.lua` — модули, которые
подключаются через `require` из `Main`.

### Структура репозитория

```
ShellCatcher/
  default.project.json     <- описание дерева для Rojo (вкл. статические Remotes)
  .gitignore
  docs/README.md
  src/
    ReplicatedStorage/     -> ReplicatedStorage (+ статическая папка Remotes из project.json)
    ServerScriptService/   -> ServerScriptService
    StarterPlayerScripts/  -> StarterPlayer.StarterPlayerScripts
```

---

## 1. Структура скриптов (что где живёт)

```
ReplicatedStorage/
  GameConfig.lua
  MonetizationConfig.lua
  PlayerProfileTemplate.lua

ServerScriptService/
  DataService.lua           (ModuleScript)
  GamePassService.lua       (ModuleScript)
  DeveloperProductService.lua (ModuleScript)
  UpgradeService.lua        (ModuleScript)  -- прокачка инструментов/акваланга/инвентаря
  InventoryService.lua      (ModuleScript)
  OxygenService.lua         (ModuleScript)
  HarpoonToolService.lua    (ModuleScript)
  CrusherDrillService.lua   (ModuleScript)
  ZoneService.lua           (ModuleScript)
  ZoneSpawnerService.lua    (ModuleScript)
  AfkSorterService.lua      (ModuleScript)
  RebirthService.lua        (ModuleScript)
  SoundService.lua          (ModuleScript)  -- централизованные звуковые крючки
  MapBuilder.lua            (ModuleScript)  -- строит всю карту-заглушку кодом
  Main.server.lua           (Script — единственная точка входа сервера)

StarterPlayerScripts/
  MasterUI.client.lua       (LocalScript) -- ВЕСЬ UI игры одним скриптом, схематичный дизайн
  ToolController.client.lua (LocalScript) -- только ввод/прицеливание, без UI
```

**Про папку Remotes:** она НЕ создаётся скриптом (старый `RemotesSetup` удалён).
Все RemoteEvent объявлены статически в `default.project.json` и существуют до запуска
любого скрипта — см. раздел 0. Поэтому `WaitForChild("Remotes")` нигде не виснет.

**Про порядок загрузки модулей:** `Main.server.lua` подключает все сервисы через
`require` в правильном порядке (DataService первым). Циклических зависимостей нет
(единственный потенциальный цикл `UpgradeService ↔ OxygenService` разорван ленивым
`require` внутри функции `BuyUpgrade`).

## 2. Система прокачки (радиальное дерево навыков)

Вся прокачка теперь живёт в `GameConfig.UpgradeTree` — каждый узел задаёт:
- `Branch` — какой ветке принадлежит (`Harpoon` / `Drill` / `Oxygen` / `Inventory`), влияет
  на цвет луча/узла (см. `GameConfig.BranchColors`)
- `Angle` / `Radius` — направление луча (градусы) и слой/кольцо от центра дерева
- `ParentKey` — ключ узла-родителя; без покупки родителя узел заблокирован
  (узлы без `ParentKey` растут прямо из центрального узла "Start" и всегда доступны)
- `BaseValue` / `ValuePerLevel` — значение статы на уровне 0 и прирост за уровень
- `BaseCost` / `CostGrowth` — стоимость первого уровня и множитель роста цены
- `MaxLevel` — потолок прокачки этого узла

`GameConfig.Upgrades` оставлен как плоский алиас на `UpgradeTree` (автогенерируется в конце
файла) — старый код, который читает `GameConfig.Upgrades[key]`, продолжает работать без
изменений.

`UpgradeService.lua` считает текущие значения статов, проверяет зависимости
(`UpgradeService.IsNodeUnlocked`) и обрабатывает покупку уровня — причём проверка
родителя выполняется и на сервере, так что обойти блокировку через прямой вызов
RemoteEvent не получится. `HarpoonToolService`, `CrusherDrillService`, `OxygenService`
и `InventoryService` читают свои статы оттуда же.



## 3. UI — один скрипт, схематичный дизайн

`MasterUI.client.lua` строит весь интерфейс игры (HUD, инвентарь, **радиальное дерево
навыков**, магазин, уведомления) программно — без вёрстки руками в Studio. Все элементы
простые прямоугольники/текст без картинок, специально чтобы было легко донастроить:

- Все цвета/шрифты лежат в таблице `THEME` в начале файла — поменяй там, перекрасится всё разом
- Везде, где должна быть иконка, стоит цветной квадрат с именем `..._IconPlaceholder` —
  найди его в Explorer (Player → PlayerGui → MasterUI) и либо замени на `ImageLabel`
  со своей картинкой, либо добавь `ImageLabel` слоем выше
- Окно магазина само показывает все записи из `MonetizationConfig` — то же самое:
  добавляешь геймпасс/продукт в конфиг, кнопка появляется в UI автоматически

### Дерево навыков (Upgrades window)

Вместо вкладок — радиальное дерево, как в ARPG-играх: центральный узел "Diver's Core" в
середине холста, от него лучами расходятся узлы 4 веток (Harpoon / Drill / Oxygen /
Inventory), каждая со своим цветом (см. `GameConfig.BranchColors`). Линия между узлом
и его родителем показывает связь; серая затемнённая линия/узел = родитель ещё не куплен.

**Зависимости (важно для баланса):** узел нельзя купить, если у него есть `ParentKey`
и этот родитель не куплен хотя бы на 1 уровень — это проверяется и на клиенте (кнопка
показывает "LOCKED"), и на сервере в `UpgradeService.IsNodeUnlocked` (так что нечестно
купить через эксплойт/прямой вызов Remote не получится).

**Как добавить новый узел в дерево:**
1. Открой `GameConfig.UpgradeTree` в `ReplicatedStorage`.
2. Добавь новую запись с `Tool`, `Stat`, `Branch`, `Angle` (направление луча в градусах),
   `Radius` (слой/кольцо от центра, целое число 1, 2, 3...), `ParentKey` (ключ узла-родителя,
   или оставь без него если хочешь, чтобы узел рос прямо из центра), плюс обычные
   `MaxLevel` / `BaseCost` / `CostGrowth` / `BaseValue` / `ValuePerLevel`.
3. Дерево само перестроится на клиенте — никакого UI-кода трогать не нужно.
4. Если это новый `Stat`, который должен на что-то влиять в игре — добери
   `UpgradeService.GetStatValue(player, "ТвойКлюч")` в соответствующем сервисе
   (`HarpoonToolService`, `CrusherDrillService`, `OxygenService` или `InventoryService`).

**Управление деревом:** холст больше окна, поэтому он скроллится (drag/scroll внутри
`ScrollingFrame`) — так дерево может расти сколько угодно без необходимости ужимать узлы.
Клик по узлу показывает его в нижней панели деталей с кнопкой покупки.

**Что нужно докрутить художественно:** сейчас узлы — однотонные ромбы с числом уровня
внутри. Замени `iconLabel` в `drawTreeNode` на `ImageLabel` со своей иконкой для каждой
ветки/узла, если хочешь визуал ближе к классическим skill-tree с иконками предметов.



## 4. Карта — построена автоматически кодом (MapBuilder.lua)

В отличие от ранней версии, тебе **не нужно** строить геометрию руками в Studio.
`MapBuilder.lua` строит абсолютно всю карту-заглушку при старте сервера: остров,
все 5 зданий, 7 NPC, и все 4 зоны лова со всеми точками спавна. Вызывается один раз
из `Main.server.lua` (`MapBuilder.BuildEverything()`), до того как `ZoneSpawnerService`
начинает спавнить силуэты/блоки.

Всё, что строится — простые `Part` (кубы/цилиндры) с понятными именами и иерархией,
совпадающей с тем, что ожидают остальные сервисы. Игра полностью играбельна на этой
геометрии: телепорты между остров/зонами работают, спавнеры находят свои точки,
здания открывают окна через `ProximityPrompt`.

### Что строится и где это найти в Explorer после старта игры

```
workspace/
  IslandSpawnPoints/        -- 6 точек спавна персонажей на острове (по кругу)
  Island/
    IslandGround            -- песочная плита-остров
    Buildings/
      shop_basic            -- зелёный куб, открывает магазин
      storage_room          -- коричневый куб, открывает инвентарь
      afk_dock              -- голубой куб, AFK-машина
      skin_workshop         -- розовый куб, открывает магазин (вкладка косметики)
      rebirth_altar         -- золотой куб, открывает ребирт
      (каждое здание: ProximityPrompt "BuildingPrompt_<id>" + Sound "AmbientSound")
    NPCs/
      NPC_1 .. NPC_7        -- цилиндры-капсулы с подписью имени и ProximityPrompt "Talk"
  Zones/
    reef / kelp / trench / vent/
      ZoneFloor             -- дно зоны
      ZoneEntranceMarker    -- куб-маркер с названием и ценой разблокировки
      SpawnPoints/          -- 6 точек, куда телепортируется игрок при входе
      CreatureSpawnPoints/  -- 14 точек для силуэтов добычи
      ResourceSpawnPoints/  -- 10 точек для ресурсных блоков
      Creatures/            -- пустая папка, сюда сервер кладёт силуэты во время игры
      Resources/            -- пустая папка, сюда сервер кладёт ресурсные блоки
```

### Как заменить заглушки на свой арт — по шагам

**1. Остров.** Найди `workspace.Island.IslandGround`, спрячь или удали его, помести
свою модель острова в то же место (вокруг `Vector3.new(0,0,0)`). Главное — не удаляй
и не переименовывай `workspace.IslandSpawnPoints` (Folder с точками спавна), иначе
игроки не будут знать, куда респаунится — можешь свободно двигать сами точки внутри.

**2. Здания.** Каждое здание сейчас — один `Part` с дочерним `ProximityPrompt`
с именем `BuildingPrompt_<building_id>` (например `BuildingPrompt_shop_basic`).
Чтобы заменить на свою модель:
   - Импортируй/собери свою модель здания.
   - Назови её **точно так же**, как сейчас называется Part (`shop_basic`, `storage_room`
     и т.д.) — `Main.server.lua` ищет здания по этому имени.
   - Перенеси `ProximityPrompt` с тем же именем (`BuildingPrompt_<id>`) внутрь своей модели
     (на любую часть модели, как Primary/корневую).
   - Опционально перенеси и `Sound "AmbientSound"`, если хочешь сохранить фоновый звук здания.

**3. NPC.** Замени цилиндр `NPC_<n>` на Rig/Model персонажа, сохрани имя `NPC_<n>` и
дочерний `ProximityPrompt` с именем `NPCPrompt_<n>` внутри модели.

**4. Зоны.** Замени `ZoneFloor` на свою геометрию рельефа — это просто декорация, на
логику не влияет. **Не переименовывай** Folder-ы `SpawnPoints`, `CreatureSpawnPoints`,
`ResourceSpawnPoints`, `Creatures`, `Resources` — остальной код ищет их по точному имени.
Количество и позиции точек внутри можно менять свободно (перетаскивай Part в Studio,
добавляй/удаляй).

**5. Силуэты добычи и ресурсные блоки.** Сейчас генерируются кодом в
`ZoneSpawnerService.lua` (функции `spawnSilhouette`/`spawnResourceBlock`) как чёрный
куб / серый камень. Чтобы заменить на свою модель: вместо `Instance.new("Part")`
клонируй свой шаблон из `ReplicatedStorage` (например
`ReplicatedStorage.Models.SilhouetteTemplate:Clone()`), но **обязательно** после
клонирования проставь те же атрибуты (`SetAttribute`), что сейчас стоят на Part —
`Health`, `BaseValue`, `CreatureId` для силуэтов; `Health`, `ResourceId`, `Amount`
для ресурсных блоков. Вся боевая логика (`HarpoonToolService`/`CrusherDrillService`)
читает именно эти атрибуты, а не тип/форму инстанса.

**6. Хочешь больше/другие зоны или здания?** Не трогай `MapBuilder.lua` вручную для
позиций — добавь зону в `GameConfig.Zones` (и опционально координаты в
`zoneWorldOffsets` внутри `MapBuilder.lua`, иначе будет дефолтный отступ `(0,0,0)`)
или здание в `GameConfig.IslandBuildings` — `MapBuilder` подхватит их автоматически
при следующем старте сервера.

## 5. Звук — все крючки расставлены, вставь свои SoundId

Все звуковые места в игре уже подключены и вызываются в нужный момент — единственное,
что нужно сделать тебе: открыть `GameConfig.SoundIds` (в `ReplicatedStorage/GameConfig.lua`)
и заменить пустые строки `""` на свои `"rbxassetid://ТВОЙ_ID"`. Пока строка пустая,
звук просто не проигрывается — игра не ломается и не ругается ошибками.

### Где живёт звуковая логика

- **`GameConfig.SoundIds`** — единственное место, где нужно вставлять ID. Каждый ключ
  прокомментирован, что это за звук и когда играет.
- **`GameConfig.SoundVolumes`** — громкость по умолчанию для каждого звука (0–1),
  настраивается отдельно от ID.
- **`SoundService.lua`** (сервер) — `SoundService.PlayAt(key, part)` проигрывает звук
  в 3D-точке (например на силуэте/блоке), `SoundService.PlayToPlayer(key, player)` шлёт
  звук персонально игроку через `RemoteEvent "PlayLocalSound"` (для UI/персональных
  уведомлений вроде "задохнулся" или "купил геймпасс").
- **`MasterUI.client.lua`** — содержит свою копию проигрывателя (`playSound`) для чисто
  клиентских событий (открытие/закрытие окна, появление toast-уведомления) и слушает
  `PlayLocalSound` от сервера для персональных звуков.

### Полный список звуковых крючков (что и когда играет)

| Ключ | Когда играет |
|---|---|
| `HarpoonFire` | выстрел сетью/гарпуном |
| `HarpoonCatchSuccess` | силуэт пойман, редкость раскрыта |
| `DrillFire` | удар дробящего инструмента по блоку |
| `DrillBreakBlock` | ресурсный блок разрушен |
| `DrillOverheat` | инструмент перегрелся |
| `OxygenLowWarning` | кислород упал ниже порога (`LowOxygenWarningAt`) |
| `Asphyxiate` | кислород обнулился, потеря части улова |
| `SellAll` | продал весь инвентарь |
| `UpgradeBuy` | купил уровень узла в дереве навыков |
| `UpgradeMaxed` | попытка купить уже максимальный узел |
| `NotEnoughCurrency` | не хватает валюты ИЛИ узел дерева заблокирован родителем |
| `RebirthSuccess` | успешный ребирт |
| `ZoneUnlock` | разблокирована новая зона лова |
| `UIClick` / `UIClose` | открытие/закрытие любого окна интерфейса |
| `NotificationPop` | появление toast-уведомления |
| `GamePassPurchased` | успешная покупка геймпасса |
| `ProductPurchased` | успешная покупка dev-продукта |
| `ZoneAmbient_<id>` | зацикленный фоновый звук конкретной зоны (вешается на `ZoneEntranceMarker`) |
| `BuildingAmbient` | зацикленный фоновый звук здания (на каждом `Sound "AmbientSound"`) |
| `NPCVoice` | звук при разговоре с NPC |

### Как добавить новый звук

1. Добавь ключ в `GameConfig.SoundIds` (и опционально громкость в `SoundVolumes`).
2. На сервере вызови `SoundService.PlayAt("ТвойКлюч", какаяТоПозиция)` или
   `SoundService.PlayToPlayer("ТвойКлюч", player)` в нужном месте сервиса.
3. Либо на клиенте просто вызови `playSound("ТвойКлюч")` внутри `MasterUI.client.lua`.

## 6. Как создать реальные Game Pass и Developer Product

1. Опубликуй игру (даже без геймплея) через `File > Publish to Roblox`.
2. Зайди на https://create.roblox.com (Creator Hub) → выбери свою игру.
3. **Game Passes:** Monetization → Passes → Create a Pass.
   - Загружаешь иконку 512×512.
   - Название и описание — бери прямо из `MonetizationConfig.GamePasses[...].Name/Description`.
   - Указываешь цену в Robux (см. рекомендованные диапазоны ниже).
   - После создания скопируй число из URL страницы пасса (это и есть `gamePassId`).
4. **Developer Products:** Monetization → Developer Products → Create a Product.
   - Аналогично: иконка, название, описание, цена.
   - Скопируй `productId`.
5. Вставь все ID в `MonetizationConfig.lua` вместо `Id = 0`.
6. Опубликуй игру повторно — без этого новые ID не попадут в работающую версию.

### Рекомендованные диапазоны цен (Robux), на основе практик жанра симуляторов
- Мелкие косметические пассы: 50–200 Robux
- Геймплейные удобства (доп. слоты, доступ к зданию): 150–400 Robux
- VIP/флагманский пасс: 300–800 Robux
- Маленькие dev-продукты (бусты, реролл): 25–80 Robux
- Валюта мелким/средним/крупным пакетом: 49 / 199 / 499 Robux (с нарастающим бонусом за объём)

Помни: Roblox забирает 30% с каждой продажи — цена в конфиге это то, что платит покупатель,
а получаешь ты 70% от неё.

## 7. Принцип "Game Pass vs Developer Product" (зафиксировано в конфиге)

- **Game Pass** = разовая покупка навсегда. Используй для: VIP, доступа к зданиям, доп. слотов,
  скинов, постоянных косметических бонусов.
- **Developer Product** = можно покупать многократно. Используй для: валюты (Shells), временных
  бустов, реролла, мгновенного сбора с AFK-машины.
- Никогда не делай валюту геймпассом — это уже учтено в `MonetizationConfig`, где все пакеты
  Shells лежат в `DeveloperProducts`, а не в `GamePasses`.

## 8. Что доделать самостоятельно (не покрыто кодом)

Карта и звуковые крючки теперь готовы как заглушки/каркас (см. разделы 4 и 5) — игра
играбельна прямо сейчас. Что осталось докрутить художественно и контентно:

- Заменить Part-заглушки острова/зданий/NPC/зон на реальные 3D-модели (см. подробный
  гайд по замене в разделе 4)
- Анимация раскрытия силуэта при поимке, анимация дробления блока
- Иконки геймпассов/продуктов для магазина (512×512 PNG) — сейчас цветные плейсхолдеры
- Реальные `SoundId` вместо заглушек (см. полный список в разделе 5)
- Полноценный UI инвентаря с отдельными предметами (сейчас продажа идёт по кнопке
  "продать всё" через `SellInventory` RemoteEvent — список предметов уже отображается,
  но без индивидуальных действий по каждому)
- Анимация персонажа при использовании инструментов (Animator/AnimationController)
- Отдельные окна для AFK-машины и ребирта (сейчас это toast-уведомления — см.
  `windowsByName` в `MasterUI.client.lua`, где можно зарегистрировать новые панели)
- Таблица лидеров, чат-теги VIP и прочие "вкусности" — крючки под них уже есть в `Perks`
- Реальное плейтестирование на 6 игроках и балансировка цифр (цены, рост стоимости,
  скорость спавна) по фактическим ощущениям от игры
